<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sobral</title>
</head>
<body>
    
<a href=" <?php echo e(route('Educacao_Infantil.EducacaoInfantil')); ?>">Ir para página de apoio á educação infantil</a>




</body>
</html><?php /**PATH C:\Projeto_Sobral\resources\views/index.blade.php ENDPATH**/ ?>