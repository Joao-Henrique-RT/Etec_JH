<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cood Fund I</title>
</head>
<body>
    <h1>BEM VINDO A PÁGINA DA COORDENADORIA DE ENSINO FUNDAMENTAL I</h1>

    <a href=" <?php echo e(route('Cood_Fund_I.Ensino_Fund_I')); ?>">Ir a Ensino Fundamental I</a>
    <br>
    <a href=" <?php echo e(route('Cood_Fund_I.Educacao_Especial')); ?>">Ir a Educação especial</a>
    <br>
    <a href=" <?php echo e(route('Cood_Fund_I.Diversidade')); ?>">Ir a Célula de educação de jovens e adultos da diversidade</a>
    <br><hr>
    <a href=" <?php echo e(route('site.principal')); ?>">RETORNAR A PÁGINA PRINCIPAL</a>



</body>
</html><?php /**PATH C:\Projeto_Sobral\resources\views/Cood_Fund_I/Cood_fund_I.blade.php ENDPATH**/ ?>