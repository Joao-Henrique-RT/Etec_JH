<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Coord Fund II</title>
</head>
<body>
    
    <h1>COORDENADORIA DE ENSINO FUNDAMENTAL II</h1>


    <a href=" <?php echo e(route('Cood_Fund_II.Proj_Vida')); ?>">CÉLULA DE PROTAGONISMO JUVENIL E PROJETO DE VIDA</a>

    <br><hr>
    <a href=" <?php echo e(route('site.principal')); ?>">RETORNAR A PÁGINA PRINCIPAL</a>



</body>
</html><?php /**PATH C:\Projeto_Sobral\resources\views/Cood_Fund_II/Cood_Fund_II.blade.php ENDPATH**/ ?>