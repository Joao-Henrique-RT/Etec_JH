<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>COORDENADORIA DA EDUCAÇÃO INFANTIL</title>
</head>
<body>
    
<h1>Bem vindo á página de Coordenadoria da Educação Infantil</h1>

    <a href=" <?php echo e(route('Ed_Infantil.EducacaoInfantil')); ?>">CÉLULA DE APOIO À GESTÃO DA EDUCAÇÃO INFANTIL</a>
    <br>
    <a href=" <?php echo e(route('Ed_Infantil.Acompanhamento')); ?>">CÉLULA DE FORMAÇÃO E ACOMPANHAMENTO</a>
    <br>
    <hr>
    <a href=" <?php echo e(route('site.principal')); ?>">RETORNAR A PÁGINA PRINCIPAL</a>


</body>
</html>    <?php /**PATH C:\Projeto_Sobral\resources\views/Ed_Infantil/Cood_Ed_Infantil.blade.php ENDPATH**/ ?>