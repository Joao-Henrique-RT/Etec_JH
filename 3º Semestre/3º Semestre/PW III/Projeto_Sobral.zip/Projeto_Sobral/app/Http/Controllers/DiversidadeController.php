<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DiversidadeController extends Controller
{
    public function index(){
        return view('Cood_Fund_I.Diversidade');
    }
}
