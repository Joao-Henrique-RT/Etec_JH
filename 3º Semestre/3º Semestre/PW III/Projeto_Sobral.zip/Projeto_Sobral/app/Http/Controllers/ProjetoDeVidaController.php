<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ProjetoDeVidaController extends Controller
{
    public function index(){
        return view('Cood_Fund_II.Proj_vida');
    }
}
