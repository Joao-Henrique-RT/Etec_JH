<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Coordenadoria_Fund_IController extends Controller
{
    public function index(){
        return view('Cood_Fund_I.Cood_Fund_I');
    }
}
