<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class EspecialController extends Controller
{
    public function index(){
        return view('Cood_Fund_I.Educacao_Especial');
    }
}
