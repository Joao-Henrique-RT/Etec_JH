<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Coordenadoria_Fund_IIController extends Controller
{
    public function index(){
        return view('Cood_Fund_II.Cood_Fund_II');
    }
}
