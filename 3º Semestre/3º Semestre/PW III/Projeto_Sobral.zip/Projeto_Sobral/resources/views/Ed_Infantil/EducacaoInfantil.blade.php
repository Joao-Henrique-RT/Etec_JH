<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CÉLULA DE APOIO À GESTÃO DA EDUCAÇÃO INFANTIL</title>
</head>
<body>
    <h1>CÉLULA DE APOIO À GESTÃO DA EDUCAÇÃO INFANTIL</h1>
    <hr>
    <a href=" {{ route('Ed_Infantil.Cood_Ed_Infantil') }}">COORDENADORIA DA EDUCAÇÃO INFANTIL</a>
</body>
</html>