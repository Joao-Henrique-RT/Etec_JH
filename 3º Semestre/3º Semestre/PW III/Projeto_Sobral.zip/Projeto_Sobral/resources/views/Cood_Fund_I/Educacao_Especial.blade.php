<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Educação Especial</title>
</head>
<body>
    <h1>Educação Especial</h1>
    
    <br><hr>
    <a href=" {{ route('Cood_Fund_I.Cood_Fund_I') }}">COORDENADORIA DE ENSINO FUNDAMENTAL I</a>
</body>
</html>