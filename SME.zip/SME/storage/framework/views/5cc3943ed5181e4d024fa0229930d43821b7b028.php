<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href=" <?php echo e(asset ('css/estilo.css')); ?>">
    

    <title>Principal</title>
</head>
<body>

    <div class="fundoMenu">
        <div class="menu">
            <a href="<?php echo e(route('site.principal')); ?>">Principal</a>
            <a href="<?php echo e(route('infantil.educacaoInfantil')); ?>">Educacao Infantil</a>
            <a href="<?php echo e(route('infantil.apoioEducacaoInfantil')); ?>">Apoio Educacao Infantil</a>
            <a href="<?php echo e(route('infantil.acompanhamento')); ?>">Celula Acompanhamento</a>
        </div>
    </div>
    <div class="fundoMenu">
        <div class="menu">
            <a href="<?php echo e(route('site.principal')); ?>">Principal</a>
            <a href="<?php echo e(route('fundamental.ensinoFundamental')); ?>">Ensino Fundamental</a>
            <a href="<?php echo e(route('fundamental.celulaEnsinoFundamental')); ?>">CelulaEnsinoFundamental</a>
            <a href="<?php echo e(route('fundamental.educacaoEspecial')); ?>">Educacao Especial</a>
            <a href="<?php echo e(route('fundamental.jovensAdultos')); ?>">Jovens e Adultos</a>
        </div>
    </div>
    <div class="fundoMenu">
    <div class="menu">
            <a href="<?php echo e(route('site.principal')); ?>">Principal</a>
            <a href="<?php echo e(route('fundamentalII.ensinoFundamentalII')); ?>">EnsinoFundamentalII</a>
            <a href="<?php echo e(route('fundamentalII.celulaProtagonismo')); ?>">celulaProtagonismo</a>
            <a href="<?php echo e(route('fundamentalII.tempoIntegral')); ?>">tempoIntegral</a>
        </div>
        </div>
        <div class="fundoMenu">
        <div class="menu">
            <a href="<?php echo e(route('site.principal')); ?>">Principal</a>
            <a href="<?php echo e(route('gestaoPedagogica.gestaoPedagogica')); ?>">gestaoPedagogica</a>
            <a href="<?php echo e(route('gestaoPedagogica.avaliacaoExterna')); ?>">avaliacaoExterna</a>
            <a href="<?php echo e(route('gestaoPedagogica.mediacaoSocial')); ?>">mediacaoSocial</a>
            <a href="<?php echo e(route('gestaoPedagogica.monitoramentoPedagogico')); ?>">monitoramentoPedagogico</a>
            <a href="<?php echo e(route('gestaoPedagogica.socioEmocional')); ?>">socioEmocional</a>
            <a href="<?php echo e(route('gestaoPedagogica.supervisaoArticulacao')); ?>">supervisaoArticulacao</a>
            <a href="<?php echo e(route('gestaoPedagogica.tutorialPedagogica')); ?>">tutorialPedagogica</a>
        </div>
    </div>
    <div class="fundoMenu">
        <div class="menu">
            <a href="<?php echo e(route('site.principal')); ?>">Principal</a>
            <a href="<?php echo e(route('gestaoEscolar.gestaoEscolar')); ?>">gestaoEscolar</a>
            <a href="<?php echo e(route('gestaoEscolar.celulaPesquisa')); ?>">celulaPesquisa</a>
            <a href="<?php echo e(route('gestaoEscolar.celulaApoioGestao')); ?>">celulaApoioGestao</a>
            <a href="<?php echo e(route('gestaoEscolar.superintendenciaEscolar')); ?>">superintendenciaEscolar</a>
            <a href="<?php echo e(route('gestaoEscolar.servicosEducacionais')); ?>">servicosEducacionais</a>
        </div>
    </div>
    <div class="fundoMenu">
        <div class="menu">
            <a href="<?php echo e(route('site.principal')); ?>">Principal</a>
            <a href="<?php echo e(route('gestaoValorizacao.gestaoValorizacao')); ?>">gestaoValorizacao</a>
            <a href="<?php echo e(route('gestaoValorizacao.celulaPagamentos')); ?>">celulaPagamentos</a>
            <a href="<?php echo e(route('gestaoValorizacao.acompanhamentoFuncional')); ?>">acompanhamentoFuncional</a>
        </div>
    </div>
    <div class="fundoMenu">
        <div class="menu">
            <a href="<?php echo e(route('site.principal')); ?>">Principal</a>
            <a href="<?php echo e(route('tecnologiaInformacao.tecnologiaInformacao')); ?>">tecnologiaInformacao</a>
            <a href="<?php echo e(route('tecnologiaInformacao.desenvolvimentoSuporte')); ?>">desenvolvimentoSuporte</a>
        </div>
    </div>
    <div class="fundoMenu">
        <div class="menu">
         <a href="<?php echo e(route('site.principal')); ?>">Principal</a>
            <a href="<?php echo e(route('gestaoEscolar.gestaoEscolar')); ?>">gestaoEscolar</a>
            <a href="<?php echo e(route('gestaoEscolar.celulaPesquisa')); ?>">celulaPesquisa</a>
            <a href="<?php echo e(route('gestaoEscolar.celulaApoioGestao')); ?>">celulaApoioGestao</a>
            <a href="<?php echo e(route('gestaoEscolar.superintendenciaEscolar')); ?>">superintendenciaEscolar</a>
            <a href="<?php echo e(route('gestaoEscolar.servicosEducacionais')); ?>">servicosEducacionais</a>
        </div>
    </div>
    <div class="fundoMenu">
        <div class="menu">
            <a href="<?php echo e(route('site.principal')); ?>">Principal</a>
            <a href="<?php echo e(route('coordenadoriaAdm.coordenadoriaAdm')); ?>">coordenadoriaAdm</a>
            <a href="<?php echo e(route('coordenadoriaAdm.logistica')); ?>">logistica</a>
            <a href="<?php echo e(route('coordenadoriaAdm.transporteEscolar')); ?>">transporteEscolar</a>
            <a href="<?php echo e(route('coordenadoriaAdm.alimentacaoEscolar')); ?>">alimentacaoEscolar</a>
            <a href="<?php echo e(route('coordenadoriaAdm.celulaObras')); ?>">celulaObras</a>
        </div>
    </div>
    <div class="fundoMenu">
        <div class="menu">
            <a href="<?php echo e(route('site.principal')); ?>">Principal</a>
            <a href="<?php echo e(route('juridico.juridico')); ?>">Juridico</a>
            <a href="<?php echo e(route('juridico.sindicancia')); ?>">sindicancia</a>
            <a href="<?php echo e(route('juridico.contratosConvenios')); ?>">contratosConvenios</a>
            <a href="<?php echo e(route('juridico.processosLicitatorios')); ?>">processosLicitatorios</a>
            <a href="<?php echo e(route('juridico.controleInterno')); ?>">controleInterno</a>
        </div>
    </div>
    <div class="fundoMenu">
        <div class="menu">
            <a href="<?php echo e(route('site.principal')); ?>">Principal</a>
            <a href="<?php echo e(route('financeiro.financeiro')); ?>">financeiro</a>
            <a href="<?php echo e(route('financeiro.contabilidade')); ?>">contabilidade</a>
            <a href="<?php echo e(route('financeiro.prestacaoContas')); ?>">prestacaoContas</a>
            <a href="<?php echo e(route('financeiro.planejAdm')); ?>">planejAdm</a>
        </div>
    </div>
    <h1>
        Página principal!!
    </h1>
    <hr>

</body>
</html><?php /**PATH C:\SME\resources\views/site/principal.blade.php ENDPATH**/ ?>