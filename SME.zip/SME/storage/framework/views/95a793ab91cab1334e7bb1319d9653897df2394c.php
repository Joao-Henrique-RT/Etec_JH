<link rel="stylesheet" href=" <?php echo e(asset ('css/estilo.css')); ?>">


    <div class="fundoMenu">
        <div class="menu">
            <a href="<?php echo e(route('site.principal')); ?>">Principal</a>
            <a href="<?php echo e(route('app.clientes')); ?>">Clientes</a>
            <a href="<?php echo e(route('app.fornecedores')); ?>">fornecedores</a>
            <a href="<?php echo e(route('app.produtos')); ?>">Produtos</a>
            <a href="<?php echo e(route('site.contato')); ?>">Contato</a>
            <a href="<?php echo e(route('site.sobre-nos')); ?>">Sobre-nos</a>
        </div>
    </div><?php /**PATH C:\SuperGestao\resources\views/geral/menu.blade.php ENDPATH**/ ?>