<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dinamico</title>
</head>
<body>
    <h1>
        Listagem de Alunos!
    </h1>
    <hr>
    <strong>Nome Aluno: </strong> <?php echo e($nomes); ?> <br>

</body>
</html><?php /**PATH C:\App_SuperGestao\SuperGestao\resources\views/site/dinamico.blade.php ENDPATH**/ ?>