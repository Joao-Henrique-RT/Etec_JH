<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href=" <?php echo e(asset ('css/estilo.css')); ?>">

    <title>SME</title>
</head>
<body>
<div class="fundoMenu">
        <div class="menu">
            <a href="<?php echo e(route('site.principal')); ?>">Principal</a>
            <a href="<?php echo e(route('juridico.juridico')); ?>">Juridico</a>
            <a href="<?php echo e(route('juridico.sindicancia')); ?>">sindicancia</a>
            <a href="<?php echo e(route('juridico.contratosConvenios')); ?>">contratosConvenios</a>
            <a href="<?php echo e(route('juridico.processosLicitatorios')); ?>">processosLicitatorios</a>
            <a href="<?php echo e(route('juridico.controleInterno')); ?>">controleInterno</a>
        </div>
    </div>
    <h1>
        Célula de Apoio Funcional e Sindicância Administrativa!!
    </h1>
    <hr>
</body>
</html><?php /**PATH C:\SME\resources\views/juridico/sindicancia.blade.php ENDPATH**/ ?>