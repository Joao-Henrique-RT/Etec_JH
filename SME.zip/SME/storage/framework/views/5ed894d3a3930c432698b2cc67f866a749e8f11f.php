<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Estatico</title>
</head>
<body>
    <h1>
        Listagem de Produtos!
    </h1>
    <hr>
    <strong>Código: </strong> <?php echo e($id); ?> <br>
    <strong>Produto: </strong> <?php echo e($produto); ?> <br>
    <strong>Fornecedor: </strong> <?php echo e($fornecedor); ?> <br>
    <strong>Preço: </strong> <?php echo e($preco); ?> <br>
    

</body>
</html><?php /**PATH C:\App_SuperGestao\SuperGestao\resources\views/site/estatico.blade.php ENDPATH**/ ?>