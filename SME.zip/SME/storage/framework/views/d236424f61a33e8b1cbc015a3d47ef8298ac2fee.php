<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href=" <?php echo e(asset ('css/estilo.css')); ?>">

    <title>SME</title>
</head>
<body>
<div class="fundoMenu">
        <div class="menu">
            <a href="<?php echo e(route('site.principal')); ?>">Principal</a>
            <a href="<?php echo e(route('coordenadoriaAdm.coordenadoriaAdm')); ?>">coordenadoriaAdm</a>
            <a href="<?php echo e(route('coordenadoriaAdm.logistica')); ?>">logistica</a>
            <a href="<?php echo e(route('coordenadoriaAdm.transporteEscolar')); ?>">transporteEscolar</a>
            <a href="<?php echo e(route('coordenadoriaAdm.alimentacaoEscolar')); ?>">alimentacaoEscolar</a>
            <a href="<?php echo e(route('coordenadoriaAdm.celulaObras')); ?>">celulaObras</a>
        </div>
    </div>
    <h1>
        Celula de Logística!!
    </h1>
    <hr>
</body>
</html><?php /**PATH C:\SME\resources\views/coordenadoriaAdm/logistica.blade.php ENDPATH**/ ?>