<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href=" <?php echo e(asset ('css/estilo.css')); ?>">

    <title>SME</title>
</head>
<body>
<div class="fundoMenu">
        <div class="menu">
            <a href="<?php echo e(route('site.principal')); ?>">Principal</a>
            <a href="<?php echo e(route('gestaoPedagogica.gestaoPedagogica')); ?>">gestaoPedagogica</a>
            <a href="<?php echo e(route('gestaoPedagogica.avaliacaoExterna')); ?>">avaliacaoExterna</a>
            <a href="<?php echo e(route('gestaoPedagogica.mediacaoSocial')); ?>">mediacaoSocial</a>
            <a href="<?php echo e(route('gestaoPedagogica.monitoramentoPedagogico')); ?>">monitoramentoPedagogico</a>
            <a href="<?php echo e(route('gestaoPedagogica.socioEmocional')); ?>">socioEmocional</a>
            <a href="<?php echo e(route('gestaoPedagogica.supervisaoArticulacao')); ?>">supervisaoArticulacao</a>
            <a href="<?php echo e(route('gestaoPedagogica.tutorialPedagogica')); ?>">tutorialPedagogica</a>
        </div>
    </div>
    <h1>
        Celula de Avaliação Externa e Educacional!!
    </h1>
    <hr>
</body>
</html><?php /**PATH C:\SME\resources\views/gestaoPedagogica/avaliacaoExterna.blade.php ENDPATH**/ ?>