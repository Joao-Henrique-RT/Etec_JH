<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href=" <?php echo e(asset ('css/estilo.css')); ?>">

    <title>SME</title>
</head>
<body>
<div class="fundoMenu">
        <div class="menu">
            <a href="<?php echo e(route('site.principal')); ?>">Principal</a>
            <a href="<?php echo e(route('tecnologiaInformacao.tecnologiaInformacao')); ?>">tecnologiaInformacao</a>
            <a href="<?php echo e(route('tecnologiaInformacao.desenvolvimentoSuporte')); ?>">desenvolvimentoSuporte</a>
        </div>
    </div>
    <h1>
        Celula de Desenvolvimento e Suporte!!
    </h1>
    <hr>
</body>
</html><?php /**PATH C:\SME\resources\views/tecnologiaInformacao/desenvolvimentoSuporte.blade.php ENDPATH**/ ?>