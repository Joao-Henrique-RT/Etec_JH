<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href=" {{ asset ('css/estilo.css') }}">

    <title>SME</title>
</head>
<body>
<div class="fundoMenu">
        <div class="menu">
            <a href="{{ route('site.principal') }}">Principal</a>
            <a href="{{ route('fundamental.ensinoFundamental') }}">ensinoFundamental</a>
            <a href="{{ route('fundamental.celulaEnsinoFundamental') }}">CelulaEnsinoFundamental</a>
            <a href="{{ route('fundamental.educacaoEspecial') }}">educacaoEspecial</a>
            <a href="{{ route('fundamental.jovensAdultos') }}">jovensAdultos</a>
        </div>
    </div>
    <h1>
        Celula de Ensino Fundamental I!!
    </h1>
    <hr>
</body>
</html>