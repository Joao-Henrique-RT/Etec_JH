<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href=" {{ asset ('css/estilo.css') }}">
    

    <title>Principal</title>
</head>
<body>

    <div class="fundoMenu">
        <div class="menu">
            <a href="{{ route('site.principal') }}">Principal</a>
            <a href="{{ route('infantil.educacaoInfantil') }}">Educacao Infantil</a>
            <a href="{{ route('infantil.apoioEducacaoInfantil') }}">Apoio Educacao Infantil</a>
            <a href="{{ route('infantil.acompanhamento') }}">Celula Acompanhamento</a>
        </div>
    </div>
    <div class="fundoMenu">
        <div class="menu">
            <a href="{{ route('site.principal') }}">Principal</a>
            <a href="{{ route('fundamental.ensinoFundamental') }}">Ensino Fundamental</a>
            <a href="{{ route('fundamental.celulaEnsinoFundamental') }}">CelulaEnsinoFundamental</a>
            <a href="{{ route('fundamental.educacaoEspecial') }}">Educacao Especial</a>
            <a href="{{ route('fundamental.jovensAdultos') }}">Jovens e Adultos</a>
        </div>
    </div>
    <div class="fundoMenu">
    <div class="menu">
            <a href="{{ route('site.principal') }}">Principal</a>
            <a href="{{ route('fundamentalII.ensinoFundamentalII') }}">EnsinoFundamentalII</a>
            <a href="{{ route('fundamentalII.celulaProtagonismo') }}">celulaProtagonismo</a>
            <a href="{{ route('fundamentalII.tempoIntegral') }}">tempoIntegral</a>
        </div>
        </div>
        <div class="fundoMenu">
        <div class="menu">
            <a href="{{ route('site.principal') }}">Principal</a>
            <a href="{{ route('gestaoPedagogica.gestaoPedagogica') }}">gestaoPedagogica</a>
            <a href="{{ route('gestaoPedagogica.avaliacaoExterna') }}">avaliacaoExterna</a>
            <a href="{{ route('gestaoPedagogica.mediacaoSocial') }}">mediacaoSocial</a>
            <a href="{{ route('gestaoPedagogica.monitoramentoPedagogico') }}">monitoramentoPedagogico</a>
            <a href="{{ route('gestaoPedagogica.socioEmocional') }}">socioEmocional</a>
            <a href="{{ route('gestaoPedagogica.supervisaoArticulacao') }}">supervisaoArticulacao</a>
            <a href="{{ route('gestaoPedagogica.tutorialPedagogica') }}">tutorialPedagogica</a>
        </div>
    </div>
    <div class="fundoMenu">
        <div class="menu">
            <a href="{{ route('site.principal') }}">Principal</a>
            <a href="{{ route('gestaoEscolar.gestaoEscolar') }}">gestaoEscolar</a>
            <a href="{{ route('gestaoEscolar.celulaPesquisa') }}">celulaPesquisa</a>
            <a href="{{ route('gestaoEscolar.celulaApoioGestao') }}">celulaApoioGestao</a>
            <a href="{{ route('gestaoEscolar.superintendenciaEscolar') }}">superintendenciaEscolar</a>
            <a href="{{ route('gestaoEscolar.servicosEducacionais') }}">servicosEducacionais</a>
        </div>
    </div>
    <div class="fundoMenu">
        <div class="menu">
            <a href="{{ route('site.principal') }}">Principal</a>
            <a href="{{ route('gestaoValorizacao.gestaoValorizacao') }}">gestaoValorizacao</a>
            <a href="{{ route('gestaoValorizacao.celulaPagamentos') }}">celulaPagamentos</a>
            <a href="{{ route('gestaoValorizacao.acompanhamentoFuncional') }}">acompanhamentoFuncional</a>
        </div>
    </div>
    <div class="fundoMenu">
        <div class="menu">
            <a href="{{ route('site.principal') }}">Principal</a>
            <a href="{{ route('tecnologiaInformacao.tecnologiaInformacao') }}">tecnologiaInformacao</a>
            <a href="{{ route('tecnologiaInformacao.desenvolvimentoSuporte') }}">desenvolvimentoSuporte</a>
        </div>
    </div>
    <div class="fundoMenu">
        <div class="menu">
         <a href="{{ route('site.principal') }}">Principal</a>
            <a href="{{ route('gestaoEscolar.gestaoEscolar') }}">gestaoEscolar</a>
            <a href="{{ route('gestaoEscolar.celulaPesquisa') }}">celulaPesquisa</a>
            <a href="{{ route('gestaoEscolar.celulaApoioGestao') }}">celulaApoioGestao</a>
            <a href="{{ route('gestaoEscolar.superintendenciaEscolar') }}">superintendenciaEscolar</a>
            <a href="{{ route('gestaoEscolar.servicosEducacionais') }}">servicosEducacionais</a>
        </div>
    </div>
    <div class="fundoMenu">
        <div class="menu">
            <a href="{{ route('site.principal') }}">Principal</a>
            <a href="{{ route('coordenadoriaAdm.coordenadoriaAdm') }}">coordenadoriaAdm</a>
            <a href="{{ route('coordenadoriaAdm.logistica') }}">logistica</a>
            <a href="{{ route('coordenadoriaAdm.transporteEscolar') }}">transporteEscolar</a>
            <a href="{{ route('coordenadoriaAdm.alimentacaoEscolar') }}">alimentacaoEscolar</a>
            <a href="{{ route('coordenadoriaAdm.celulaObras') }}">celulaObras</a>
        </div>
    </div>
    <div class="fundoMenu">
        <div class="menu">
            <a href="{{ route('site.principal') }}">Principal</a>
            <a href="{{ route('juridico.juridico') }}">Juridico</a>
            <a href="{{ route('juridico.sindicancia') }}">sindicancia</a>
            <a href="{{ route('juridico.contratosConvenios') }}">contratosConvenios</a>
            <a href="{{ route('juridico.processosLicitatorios') }}">processosLicitatorios</a>
            <a href="{{ route('juridico.controleInterno') }}">controleInterno</a>
        </div>
    </div>
    <div class="fundoMenu">
        <div class="menu">
            <a href="{{ route('site.principal') }}">Principal</a>
            <a href="{{ route('financeiro.financeiro') }}">financeiro</a>
            <a href="{{ route('financeiro.contabilidade') }}">contabilidade</a>
            <a href="{{ route('financeiro.prestacaoContas') }}">prestacaoContas</a>
            <a href="{{ route('financeiro.planejAdm') }}">planejAdm</a>
        </div>
    </div>
    <h1>
        Página principal!!
    </h1>
    <hr>

</body>
</html>