<link rel="stylesheet" href=" {{ asset ('css/estilo.css') }}">


    <div class="fundoMenu">
        <div class="menu">
            <a href="{{ route('site.principal') }}">Educação Infantil</a>
            <a href="{{ route('app.clientes') }}">Gestão Educação Infantil</a>
            <a href="{{ route('app.fornecedores') }}">Formação e Acompanhamento</a>
        </div>
    </div>