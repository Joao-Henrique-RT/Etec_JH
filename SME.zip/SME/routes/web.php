<?php

use App\Http\Controllers\AcompanhamentoFuncionalController;
use App\Http\Controllers\AlimentacaoEscolarController;
use App\Http\Controllers\ApoioEducacaoInfantilController;
use App\Http\Controllers\AvaliacaoExternaController;
use App\Http\Controllers\CelulaAcompanhamentoController;
use App\Http\Controllers\CelulaApoioGestaoController;
use App\Http\Controllers\CelulaEnsinoFundamentalController;
use App\Http\Controllers\CelulaObrasController;
use App\Http\Controllers\CelulaPagamentosController;
use App\Http\Controllers\CelulaPesquisaController;
use App\Http\Controllers\CelulaProtagonismoController;
use App\Http\Controllers\ContabilidadeController;
use App\Http\Controllers\ContratosConveniosController;
use App\Http\Controllers\ControleInternoController;
use App\Http\Controllers\CoordenadoriaAdmController;
use App\Http\Controllers\DesenvolvimentoSuporteController;
use App\Http\Controllers\EducacaoEspecialController;
use App\Http\Controllers\EducacaoInfantilController;
use App\Http\Controllers\EnsinoFundamentalController;
use App\Http\Controllers\GestaoPedagogicaController;
use App\Http\Controllers\JovensAdultosController;
use App\Http\Controllers\MediacaoSocialController;
use App\Http\Controllers\MonitoramentoPedagogicoController;
use App\Http\Controllers\PrincipalController;
use App\Http\Controllers\SocioEmocionalController;
use App\Http\Controllers\SupervisaoArticulacaoController;
use App\Http\Controllers\TempoIntegralController;
use App\Http\Controllers\EnsinoFundamentalIIController;
use App\Http\Controllers\FinanceiroController;
use App\Http\Controllers\GestaoEscolarController;
use App\Http\Controllers\GestaoValorizacaoController;
use App\Http\Controllers\JuridicoController;
use App\Http\Controllers\LogisticaAdmController;
use App\Http\Controllers\LogisticaController;
use App\Http\Controllers\PlanejAdmController;
use App\Http\Controllers\PrestacaoContasController;
use App\Http\Controllers\ProcessosLicitatoriosController;
use App\Http\Controllers\ServicosEducacionaisController;
use App\Http\Controllers\SindicanciaController;
use App\Http\Controllers\SuperintendenciaEscolarController;
use App\Http\Controllers\TecnologiaInformacaoController;
use App\Http\Controllers\TransporteEscolarController;
use App\Http\Controllers\TutorialPedagogicaController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

route::get('/', [PrincipalController::class, 'index'])->name('site.principal');

//infantil
route::get('sistema/educacaoInfantil', [EducacaoInfantilController::class, 'index'])->name('infantil.educacaoInfantil');

route::get('sistema/apoioEducacaoInfantil', [ApoioEducacaoInfantilController::class, 'index'])->name('infantil.apoioEducacaoInfantil');


route::get('sistema/celulaAcompanhamento', [CelulaAcompanhamentoController::class, 'index'])->name('infantil.acompanhamento');



//fundamental
route::get('sistema/ensinoFundamental', [EnsinoFundamentalController::class, 'index'])->name('fundamental.ensinoFundamental');

route::get('sistema/celulaEnsinoFundamental', [CelulaEnsinoFundamentalController::class, 'index'])->name('fundamental.celulaEnsinoFundamental');


route::get('sistema/educacaoEspecial', [EducacaoEspecialController::class, 'index'])->name('fundamental.educacaoEspecial');

route::get('sistema/jovensAdultos', [JovensAdultosController::class, 'index'])->name('fundamental.jovensAdultos');

//fundamental II
route::get('sistema/ensinoFundamentalII', [EnsinoFundamentalIIController::class, 'index'])->name('fundamentalII.ensinoFundamentalII');

route::get('sistema/celulaProtagonismo', [CelulaProtagonismoController::class, 'index'])->name('fundamentalII.celulaProtagonismo');

route::get('sistema/tempoIntegral', [TempoIntegralController::class, 'index'])->name('fundamentalII.tempoIntegral');

//Gestão Pedagogica
route::get('sistema/gestaoPedagogica', [GestaoPedagogicaController::class, 'index'])->name('gestaoPedagogica.gestaoPedagogica');

route::get('sistema/avaliacaoExterna', [AvaliacaoExternaController::class, 'index'])->name('gestaoPedagogica.avaliacaoExterna');

route::get('sistema/mediacaoSocial', [MediacaoSocialController::class, 'index'])->name('gestaoPedagogica.mediacaoSocial');

route::get('sistema/monitoramentoPedagogico', [MonitoramentoPedagogicoController::class, 'index'])->name('gestaoPedagogica.monitoramentoPedagogico');

route::get('sistema/socioEmocional', [SocioEmocionalController::class, 'index'])->name('gestaoPedagogica.socioEmocional');

route::get('sistema/supervisaoArticulacao', [SupervisaoArticulacaoController::class, 'index'])->name('gestaoPedagogica.supervisaoArticulacao');

route::get('sistema/tutorialPedagogica', [TutorialPedagogicaController::class, 'index'])->name('gestaoPedagogica.tutorialPedagogica');

//Gestão Escolar
route::get('sistema/celulaApoioGestao', [CelulaApoioGestaoController::class, 'index'])->name('gestaoEscolar.celulaApoioGestao');

route::get('sistema/celulaPesquisa', [CelulaPesquisaController::class, 'index'])->name('gestaoEscolar.celulaPesquisa');

route::get('sistema/gestaoEscolar', [GestaoEscolarController::class, 'index'])->name('gestaoEscolar.gestaoEscolar');

route::get('sistema/servicosEducacionais', [ServicosEducacionaisController::class, 'index'])->name('gestaoEscolar.servicosEducacionais');

route::get('sistema/superintendenciaEscolar', [SuperintendenciaEscolarController::class, 'index'])->name('gestaoEscolar.superintendenciaEscolar');

//Gestão Valorização
route::get('sistema/gestaoValorizacao', [GestaoValorizacaoController::class, 'index'])->name('gestaoValorizacao.gestaoValorizacao');

route::get('sistema/celulaPagamentos', [CelulaPagamentosController::class, 'index'])->name('gestaoValorizacao.celulaPagamentos');

route::get('sistema/acompanhamentoFuncional', [AcompanhamentoFuncionalController::class, 'index'])->name('gestaoValorizacao.acompanhamentoFuncional');

// Tecnologia da Informação
route::get('sistema/desenvolvimentoSuporte', [DesenvolvimentoSuporteController::class, 'index'])->name('tecnologiaInformacao.desenvolvimentoSuporte');

route::get('sistema/tecnologiaInformacao', [TecnologiaInformacaoController::class, 'index'])->name('tecnologiaInformacao.tecnologiaInformacao');

//Coordenadoria Administrativa

route::get('sistema/coordenadoriaAdm', [CoordenadoriaAdmController::class, 'index'])->name('coordenadoriaAdm.coordenadoriaAdm');

route::get('sistema/alimentacaoEscolar', [AlimentacaoEscolarController::class, 'index'])->name('coordenadoriaAdm.alimentacaoEscolar');

route::get('sistema/celulaObras', [CelulaObrasController::class, 'index'])->name('coordenadoriaAdm.celulaObras');

route::get('sistema/logistica', [LogisticaController::class, 'index'])->name('coordenadoriaAdm.logistica');

route::get('sistema/transporteEscolar', [TransporteEscolarController::class, 'index'])->name('coordenadoriaAdm.transporteEscolar');

//Juridico
route::get('sistema/juridico', [JuridicoController::class, 'index'])->name('juridico.juridico');

route::get('sistema/sindicancia', [SindicanciaController::class, 'index'])->name('juridico.sindicancia');

route::get('sistema/contratosConvenios', [ContratosConveniosController::class, 'index'])->name('juridico.contratosConvenios');

route::get('sistema/processosLicitatorios', [ProcessosLicitatoriosController::class, 'index'])->name('juridico.processosLicitatorios');

route::get('sistema/controleInterno', [ControleInternoController::class, 'index'])->name('juridico.controleInterno');

//Financeiro
route::get('sistema/financeiro', [FinanceiroController::class, 'index'])->name('financeiro.financeiro');

route::get('sistema/contabilidade', [ContabilidadeController::class, 'index'])->name('financeiro.contabilidade');

route::get('sistema/prestacaoContas', [PrestacaoContasController::class, 'index'])->name('financeiro.prestacaoContas');

route::get('sistema/planejAdm', [PlanejAdmController::class, 'index'])->name('financeiro.planejAdm');




