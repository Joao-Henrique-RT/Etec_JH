<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TutorialPedagogicaController extends Controller
{
    public function index(){
        return view ('gestaoPedagogica.tutorialPedagogica');
    }
}
