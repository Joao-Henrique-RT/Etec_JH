<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TempoIntegralController extends Controller
{
    public function index(){
        return view ('fundamentalII.tempoIntegral');
    }
}
