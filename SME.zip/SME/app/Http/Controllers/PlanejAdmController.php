<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PlanejAdmController extends Controller
{
    public function index(){
        return view ('financeiro.planejAdm');
    }
}
