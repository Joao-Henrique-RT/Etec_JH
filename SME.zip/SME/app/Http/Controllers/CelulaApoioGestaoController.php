<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CelulaApoioGestaoController extends Controller
{
    public function index(){
        return view ('gestaoEscolar.celulaApoioGestao');
    }
}
