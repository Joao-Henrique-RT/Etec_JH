<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MediacaoSocialController extends Controller
{
    public function index(){
        return view ('gestaoPedagogica.mediacaoSocial');
    }
}
