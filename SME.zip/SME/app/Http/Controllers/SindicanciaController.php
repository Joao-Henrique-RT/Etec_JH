<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SindicanciaController extends Controller
{
    public function index(){
        return view ('juridico.sindicancia');
    }
}
