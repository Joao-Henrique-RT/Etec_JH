<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ContabilidadeController extends Controller
{
    public function index(){
        return view ('financeiro.contabilidade');
    }
}
