<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TransporteEscolarController extends Controller
{
    public function index(){
        return view ('coordenadoriaAdm.transporteEscolar');
    }
}
