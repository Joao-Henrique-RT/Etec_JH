<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ServicosEducacionaisController extends Controller
{
    public function index(){
        return view ('gestaoEscolar.servicosEducacionais');
    }
}
